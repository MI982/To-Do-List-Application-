// Navbar.jsx

import React from 'react';
import './Navbar.css'; // You can create this file for styling if needed

const Navbar = () => {
  return (
    <nav className="navbar">
      <div className="navbar-logo">
        <a href="/">To-Do List</a>
      </div>
      <ul className="navbar-links">
        <li><a href="/">Home</a></li>
        <li><a href="/about">About</a></li>
        {/* Add more links as needed */}
      </ul>
    </nav>
  );
};

export default Navbar;
